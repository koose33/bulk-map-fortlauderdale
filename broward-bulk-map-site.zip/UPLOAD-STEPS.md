# Uploading the new Broward Bulk Trash map

1. Go to https://github.com/koose33/bulk-map-fortlauderdale
2. Click **Add file → Upload files**.
3. Drag in EVERYTHING from this folder (index.html, Broward-Cities.geojson and all 14 Bulk-Map-*.geojson files).
   - index.html replaces the old one. Keep the name exactly "index.html".
4. Click **Commit changes**. Wait 1–2 minutes, then open https://koose33.github.io/bulk-map-fortlauderdale/
   (hard-refresh: Cmd+Shift+R).

## Old files you can delete from the repo afterwards (no longer used)
bulk-map-fortlauderdale.geojson, wilton-manors-zones-2025.geojson, oakland-park-zones.geojson,
pompano-beach-zones.geojson, and every other *-zones.geojson file, plus Broward_County_Cities.geojson
(replaced by the smaller Broward-Cities.geojson).

## How the files fit together
- index.html – the whole app (map, colors, hover, zone details, calendar, directions).
- Broward-Cities.geojson – outlines of every Broward city (the zoomed-out rainbow map).
- Bulk-Map-<City>.geojson – each city's pickup zones. Each zone has `name`, `schedule`,
  optional `bulk_dates` (exact dates from the city) and a `rule` that keeps dates repeating
  into future years. To add a city: drop its file in and add one line to `CITIES` in index.html.
